#!/usr/bin/env python3
from brain_games.games_logics.brain_calc_logic import brain_calc


def main():
    print('Welcome to the Brain Games!')
    brain_calc()


if __name__ == '__main__':
    main()
